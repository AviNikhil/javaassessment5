package com.infinite.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.database.DataBase;

/**
 * @author sainikhilk
 *
 */
@Controller
public class LoginController {

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String loginrecord(HttpServletRequest request, HttpServletResponse response) {
		Connection con = null; //declaring connection con
		//PreparedStatement ps=null;
		//ResultSet s = null;
		String username = request.getParameter("username"); //requesting user parameter from jsp
		String password = request.getParameter("password");//requesting password parameter from jsp
		try {
			DataSource ds = DataBase.getdatabase();
			con = ds.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from login where username=? and password = ?");
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet s = ps.executeQuery(); //validating credentials
			System.out.println("process");
			if (s.next()) {
				System.out.println("success");
				return "welcome";  //if valid credentials
			} else {
				return "invalid";  //invalid credentials
			}

		} catch (Exception e) {
			System.out.print(e);
		} finally {
			try {
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		return null;

	}
}
