package com.infinite.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.database.DataBase;

/**
 * @author sainikhilk
 *
 */
@Controller
public class RegistrationController {
	
	@RequestMapping(value="/register",method=RequestMethod.POST)
	public String loginrecord(HttpServletRequest request, HttpServletResponse response) {
		Connection con = null;//declaring connection con
		//PreparedStatement ps=null;
		//ResultSet s = null;
		String username = request.getParameter("username"); //requesting user parameter from jsp
		String email= request.getParameter("email");  //requesting email parameter from jsp
		String password=request.getParameter("password"); //requesting password parameter from jsp
		String date = request.getParameter("birthday"); //requesting birthday parameter from jsp
		String gender=request.getParameter("gender"); //requesting gender parameter from jsp
		String profession=request.getParameter("profession"); //requesting profession parameter from jsp
		String married=request.getParameter("married"); //requesting married parameter from jsp
		try {
			DataSource ds = DataBase.getdatabase();
			con = ds.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into registration values(?,?,?,?,?,?,?)");
			ps.setString(1, username);
			ps.setString(2, email);
			ps.setString(3, password);
			ps.setString(4,date);
			ps.setString(5, profession);
			ps.setString(6, gender);
			ps.setString(7, married);

			int r=ps.executeUpdate();
			if(r==1){
				return "success";
			}
			System.out.println("process");
			/*if (s.next()) {
				System.out.println("success");
				return "welcome";
			} else {
				return "invalid";
			}*/

		} catch (Exception e) {
			System.out.print(e);
		} finally {
			try {
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		return "invalid";

	}

}
